import cv2, glob, numpy as np
fs = sorted(glob.glob('all/*.png'))
fc = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
out=[]
for i in range(0,len(fs),5):
    g = cv2.cvtColor(cv2.imread(fs[i]), cv2.COLOR_BGR2GRAY)
    r = fc.detectMultiScale(g,1.1,6,minSize=(60,60))
    if len(r):
        x,y,w,h = max(r,key=lambda a:a[2])
        out.append((round(i/30,1), int(w), int(x+w/2), int(y+h/2)))
    else: out.append((round(i/30,1),None,None,None))
# print as time:width:cx:cy
print(' '.join(f"{t}:{w}:{cx}:{cy}" if w else f"{t}:-" for t,w,cx,cy in out))
