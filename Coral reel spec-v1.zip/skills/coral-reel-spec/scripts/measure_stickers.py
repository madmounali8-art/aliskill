import cv2, glob, numpy as np
fs = sorted(glob.glob('all/*.png'))
rows=[]
for i,f in enumerate(fs):
    im = cv2.imread(f).astype(int); b,g,r = im[:,:,0],im[:,:,1],im[:,:,2]
    top = slice(0,260)
    coral = ((abs(r-0xDC)<22)&(abs(g-0x74)<22)&(abs(b-0x58)<22))[top].sum()
    black = (im.max(axis=2)<45)[top].sum()
    white = (im.min(axis=2)>232)[top].sum()
    cap = (im.min(axis=2)>232)[600:650, 120:360].sum()
    rows.append((i/30,coral,black,white,cap))
rows=np.array(rows)
np.save('feat.npy',rows)
def iv(col,th,name,gap=6):
    on = rows[:,col]>th; out=[]; s=None
    for k,v in enumerate(on):
        if v and s is None: s=k
        if not v and s is not None:
            out.append([s,k-1]); s=None
    if s is not None: out.append([s,len(on)-1])
    m=[]
    for a in out:
        if m and a[0]-m[-1][1]<=gap: m[-1][1]=a[1]
        else: m.append(a)
    print(name, [(round(a/30,2),round(b/30,2)) for a,b in m if b-a>=4])
iv(1,120,'coral top')
iv(2,150,'black top')
iv(3,900,'white top')
iv(4,200,'caption on',gap=3)
